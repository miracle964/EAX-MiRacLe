"""
EAX Reverb  -  hosts the ORIGINAL ReverbPresets DLL (the exact EAX engine + 7-band equalizer)
inside a small Windows window, and runs your audio through it.

Run:   pip install numpy sounddevice
       python EAX_Reverb.py        (ReverbPresets64.dll must be in the same folder)

Public domain (Unlicense).
"""
import ctypes
import json
import os
import re
import struct
import sys
import threading
import uuid

import numpy as np

try:
    import sounddevice as sd
except Exception:
    sd = None

HERE = os.path.dirname(os.path.abspath(__file__))
SETTINGS_FILE = os.path.join(HERE, "EAX_Reverb.json")
# settings are kept in %APPDATA% (always writable, survives moving / re-extracting the folder) and a copy next to the program
SETTINGS_PATHS = (os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "EAX_Reverb", "EAX_Reverb.json"), SETTINGS_FILE)
BLOCK = 256                   # default buffer size (frames); can be changed in the window
SETTINGS_VERSION = 2          # old files saved with the big 1024 buffer are moved to the new low-latency default once
LOW_LATENCY = True            # ask the sound driver for its smallest buffer (falls back to the old safe value if it refuses)
MAX_BLOCK = 4096              # largest block the plugin is told to expect
BLOCK_CHOICES = ("256", "512", "1024", "2048")

# ---- the console list (name, default Effects Amount) - same order as the DLL's programs
PRESETS = [("Auditorium", 50), ("Ball Park", 65), ("Bathroom", 50), ("Cathedral", 50), ("Chapel", 65),
           ("Church", 50), ("Concert Hall", 50), ("Garage", 50), ("Haunted Cavern", 50), ("Indoor Arena", 60),
           ("Jazz Club", 65), ("Living Room", 50), ("Opera House", 50), ("Small Room", 50), ("Theater", 50)]
DEFAULT_PRESET = 6   # Concert Hall

BAND_NAMES = ("125", "250", "500", "1k", "2k", "4k", "8k")
CURVES = [
    ("Flat",         (0, 0, 0, 0, 0, 0, 0)),
    ("Bass Boost",   (6, 4, 2, 0, 0, 0, 0)),
    ("Treble Boost", (0, 0, 0, 0, 2, 4, 6)),
    ("Loudness",     (5, 3, 0, -1, 0, 3, 5)),
    ("Vocal",        (-2, -1, 1, 3, 3, 1, -1)),
    ("Rock",         (4, 2, -1, -2, 1, 3, 4)),
    ("Warm",         (3, 2, 1, 0, -1, -2, -3)),
    ("Bright",       (-2, -1, 0, 1, 2, 3, 4)),
]

# ---- DLL parameters (see the plugin's README): 0 preset, 1 amount, 2 enable, 3 EQ, 4..10 bands, 11 level
P_PRESET, P_AMOUNT, P_ENABLE, P_EQ, P_BAND0, P_LEVEL = 0, 1, 2, 3, 4, 11

# =============================================================================
#  Minimal VST2 host (ctypes)
# =============================================================================
c = ctypes
HOSTCALL = c.CFUNCTYPE(c.c_ssize_t, c.c_void_p, c.c_int32, c.c_int32, c.c_ssize_t, c.c_void_p, c.c_float)
DISPATCH = c.CFUNCTYPE(c.c_ssize_t, c.c_void_p, c.c_int32, c.c_int32, c.c_ssize_t, c.c_void_p, c.c_float)
PROCESS = c.CFUNCTYPE(None, c.c_void_p, c.POINTER(c.POINTER(c.c_float)), c.POINTER(c.POINTER(c.c_float)), c.c_int32)
SETPARAM = c.CFUNCTYPE(None, c.c_void_p, c.c_int32, c.c_float)
GETPARAM = c.CFUNCTYPE(c.c_float, c.c_void_p, c.c_int32)


class AEffect(c.Structure):
    _fields_ = [("magic", c.c_int32), ("dispatcher", c.c_void_p), ("process", c.c_void_p),
                ("setParameter", c.c_void_p), ("getParameter", c.c_void_p),
                ("numPrograms", c.c_int32), ("numParams", c.c_int32), ("numInputs", c.c_int32),
                ("numOutputs", c.c_int32), ("flags", c.c_int32),
                ("resvd1", c.c_ssize_t), ("resvd2", c.c_ssize_t),
                ("initialDelay", c.c_int32), ("realQualities", c.c_int32), ("offQualities", c.c_int32),
                ("ioRatio", c.c_float), ("object", c.c_void_p), ("user", c.c_void_p),
                ("uniqueID", c.c_int32), ("version", c.c_int32),
                ("processReplacing", c.c_void_p), ("processDoubleReplacing", c.c_void_p),
                ("future", c.c_char * 56)]


def _host_callback(effect, opcode, index, value, pointer, opt):
    return 2400 if opcode == 1 else 0       # audioMasterVersion -> VST 2.4


class Plugin:
    """Loads a VST2 DLL (or wraps an existing AEffect address) and exposes parameters + processing."""

    def __init__(self, path=None, address=None):
        self._keep = []
        if path:
            dll = c.CDLL(path)
            entry = getattr(dll, "VSTPluginMain", None) or getattr(dll, "main")
            entry.restype = c.c_void_p
            host = HOSTCALL(_host_callback)
            entry.argtypes = [HOSTCALL]
            self._keep += [dll, host]
            address = entry(host)
        if not address:
            raise RuntimeError("the DLL did not return a plugin")
        self.address = address
        self.fx = AEffect.from_address(address)
        if self.fx.magic != 0x56737450:
            raise RuntimeError("this is not a VST2 plugin")
        self._dispatch = DISPATCH(self.fx.dispatcher)
        self._set = SETPARAM(self.fx.setParameter)
        self._get = GETPARAM(self.fx.getParameter)
        self._replace = PROCESS(self.fx.processReplacing)
        self.call(0)                                # effOpen

    def call(self, opcode, index=0, value=0, pointer=None, opt=0.0):
        return self._dispatch(self.address, opcode, index, value, pointer, opt)

    def start(self, sample_rate):
        self.call(10, opt=float(sample_rate))       # effSetSampleRate
        self.call(11, value=MAX_BLOCK)              # effSetBlockSize (maximum)
        self.call(12, value=1)                      # effMainsChanged on

    def stop(self):
        self.call(12, value=0)

    def close(self):
        self.call(1)                                # effClose frees the plugin

    def set(self, index, value):
        self._set(self.address, index, c.c_float(float(min(max(value, 0.0), 1.0))))

    def get(self, index):
        return float(self._get(self.address, index))

    def process(self, left, right, out_left, out_right):
        ins = (c.POINTER(c.c_float) * 2)(left.ctypes.data_as(c.POINTER(c.c_float)), right.ctypes.data_as(c.POINTER(c.c_float)))
        outs = (c.POINTER(c.c_float) * 2)(out_left.ctypes.data_as(c.POINTER(c.c_float)), out_right.ctypes.data_as(c.POINTER(c.c_float)))
        self._replace(self.address, ins, outs, len(left))


class Console:
    """The plugin seen as the EAX console: preset, amount, enable, equalizer."""

    def __init__(self, plugin):
        self.plugin = plugin

    def preset(self, index):
        self.plugin.set(P_PRESET, index / 14.0)

    def amount(self, value):                 # amount of the CURRENT preset, 0..100
        self.plugin.set(P_AMOUNT, value / 100.0)

    def read_amount(self):
        return self.plugin.get(P_AMOUNT) * 100.0

    def enable(self, on):
        self.plugin.set(P_ENABLE, 1.0 if on else 0.0)

    def eq_enable(self, on):
        self.plugin.set(P_EQ, 1.0 if on else 0.0)

    def band(self, index, decibels):         # -12 .. +12
        self.plugin.set(P_BAND0 + index, (decibels + 12.0) / 24.0)

    def level(self, decibels):               # -24 .. 0
        self.plugin.set(P_LEVEL, 1.0 + decibels / 24.0)


class Pipe:
    """Joins the input stream to the output stream.

    The microphone and the virtual cable run on two DIFFERENT clocks. A plain duplex stream between two
    devices slowly drifts apart and produces clicks, stutter and noise. Here a small cushion of audio is kept
    between the two, and it is stretched / squeezed by a few hundredths of a percent (inaudible) so that it
    never runs dry and never overflows."""

    def __init__(self, rate, block):
        self.rate = rate
        self.block = block
        self.ceiling = max(block * 2, int(rate * 0.06))                 # the old fixed cushion (60 ms) is now only the upper limit
        self.target = min(self.ceiling, max(int(block * 1.5), int(rate * 0.012))) if LOW_LATENCY else self.ceiling
        self.cap = max(rate, block * 16)
        self.buf = np.zeros((self.cap, 2), np.float32)
        self.r = 0
        self.count = 0
        self.lock = threading.Lock()
        self.primed = False
        self.carry = 0.0
        self.under = 0
        self.over = 0

    def push(self, stereo):
        n = len(stereo)
        with self.lock:
            if n >= self.cap:
                stereo, n = stereo[-self.cap:], self.cap
                self.r, self.count = 0, 0
                self.over += 1
            spill = self.count + n - self.cap
            if spill > 0:                                   # too much waiting: drop the oldest
                self.r = (self.r + spill) % self.cap
                self.count -= spill
                self.over += 1
            w = (self.r + self.count) % self.cap
            first = min(n, self.cap - w)
            self.buf[w:w + first] = stereo[:first]
            if n > first:
                self.buf[:n - first] = stereo[first:]
            self.count += n

    def pull(self, frames):
        """Returns (frames, 2) float32, or None while the cushion is filling."""
        with self.lock:
            if not self.primed:
                if self.count < self.target:
                    return None
                self.primed = True
            err = (self.count - self.target) / float(self.rate)          # seconds above/below the cushion
            ratio = 1.0 + min(max(err * 0.04, -0.005), 0.005)
            want = frames * ratio + self.carry
            need = max(2, int(want))
            self.carry = want - int(want)
            if self.count < need:
                self.primed = False
                self.carry = 0.0
                self.under += 1
                self.target = min(self.ceiling, self.target + self.block)      # ran dry: keep a slightly bigger cushion from now on
                return None
            chunk = self.buf[(self.r + np.arange(need)) % self.cap]
            self.r = (self.r + need) % self.cap
            self.count -= need
        if need != frames:
            x = np.linspace(0.0, need - 1.0, frames)
            xp = np.arange(need)
            chunk = np.stack([np.interp(x, xp, chunk[:, 0]), np.interp(x, xp, chunk[:, 1])], axis=1)
        return chunk


# =============================================================================
#  Extra voice tools (OFF by default; when off the audio path is exactly what it was).
#  They work on the dry signal BEFORE it reaches the DLL, so the DLL / equalizer are never touched.
# =============================================================================
class PitchShifter:
    """Live 'speed' for the voice: two crossfading read heads on a short delay line (tape-speed feel).
    Ratio > 1 = faster / higher, ratio < 1 = slower / deeper. The delay stays constant (~30 ms), so it never
    falls behind real time - a live stream can not be time-stretched without growing a delay."""

    def __init__(self, rate):
        self.W = max(256, int(rate * 0.060))
        self.L = 1 << 16
        self.reset()

    def reset(self):
        self.buf = np.zeros((self.L, 2), np.float32)
        self.w = 0
        self.phase = 0.0

    def process(self, x, ratio):
        n = len(x)
        L, W = self.L, self.W
        steps = np.arange(n)
        self.buf[(self.w + steps) % L] = x
        t = (self.w + steps).astype(np.float64)
        ph = self.phase + (1.0 - ratio) / W * np.arange(1, n + 1)
        out = np.zeros((n, 2), np.float32)
        for off in (0.0, 0.5):
            p = (ph + off) % 1.0
            pos = t - (p * W + 2.0)
            i0 = np.floor(pos).astype(np.int64)
            fr = (pos - i0).astype(np.float32)[:, None]
            a = self.buf[i0 % L]
            b = self.buf[(i0 + 1) % L]
            out += (a + (b - a) * fr) * (np.sin(np.pi * p) ** 2).astype(np.float32)[:, None]
        self.phase = float(ph[-1] % 1.0)
        self.w += n
        return out


class Reverser:
    """Plays the voice backwards in short pieces (a fixed delay of one piece, with tiny fades so it never clicks)."""

    def __init__(self, rate, ms):
        self.ms = ms
        self.N = max(512, int(rate * ms / 1000.0))
        fade = max(8, min(int(rate * 0.008), self.N // 4))
        ramp = np.linspace(0.0, 1.0, fade, dtype=np.float32)
        env = np.ones(self.N, np.float32)
        env[:fade] = ramp
        env[-fade:] = ramp[::-1]
        self.env = env[:, None]
        self.inq = np.zeros((0, 2), np.float32)
        self.outq = np.zeros((self.N, 2), np.float32)

    def process(self, x):
        n = len(x)
        self.inq = np.concatenate((self.inq, x))
        while len(self.inq) >= self.N:
            piece = self.inq[:self.N][::-1] * self.env
            self.inq = self.inq[self.N:]
            self.outq = np.concatenate((self.outq, piece))
        out = self.outq[:n]
        self.outq = self.outq[n:]
        if len(out) < n:
            out = np.concatenate((out, np.zeros((n - len(out), 2), np.float32)))
        return out


# =============================================================================
#  Windows only: list running apps and capture the sound of ONE app (process loopback, Windows 10 2004+ / 11).
#  Nothing here runs unless you pick an app in  Effects > App Source.
# =============================================================================
HIDE_APPS = {"explorer.exe", "python.exe", "pythonw.exe", "py.exe", "cmd.exe", "conhost.exe", "windowsterminal.exe",
             "textinputhost.exe", "searchhost.exe", "applicationframehost.exe", "systemsettings.exe",
             "shellexperiencehost.exe", "startmenuexperiencehost.exe", "lockapp.exe", "taskmgr.exe", "dwm.exe"}


class Spatial3D:
    """CMSS 3D Headphone style virtual surround: the stereo sound is spread over five virtual speakers (front L/R, centre,
    rear L/R) and each one is placed around the head with a head model (time + level + high-frequency shadow difference
    between the two ears). Pure numpy, lives after the reverb so the echo is in 3D too."""
    TAPS = 96
    SPEAKERS = (("FL", -30.0), ("FR", 30.0), ("C", 0.0), ("RL", -110.0), ("RR", 110.0))
    GAINS = {"FL": 0.80, "FR": 0.80, "C": 0.85, "RL": 0.65, "RR": 0.65}

    def __init__(self, rate):
        self.rate = rate
        self.irs = {name: self.hrir(az) for name, az in self.SPEAKERS}
        self.hist = {name: np.zeros(self.TAPS - 1, np.float32) for name, _ in self.SPEAKERS}
        self.d1, self.d2 = int(0.011 * rate), int(0.017 * rate)               # the rear speakers get the ambience, a little later
        self.dmax = self.d2
        self.sbuf = np.zeros(self.dmax, np.float32)

    def ear(self, delay_s, fc, gain):
        taps = np.zeros(self.TAPS, np.float64)
        a = math.exp(-2.0 * math.pi * fc / self.rate)
        lp = (1.0 - a) * a ** np.arange(self.TAPS - 40)                        # one-pole low-pass response (head shadow)
        d = delay_s * self.rate
        d0 = int(d)
        f = d - d0
        taps[d0:d0 + len(lp)] += (1.0 - f) * lp
        taps[d0 + 1:d0 + 1 + len(lp)] += f * lp[:len(taps) - d0 - 1][:len(lp)]
        return (taps * gain).astype(np.float32)

    def hrir(self, az):
        th = math.radians(az)
        side = abs(math.sin(th))
        ang = math.asin(side)                                                    # front/back have the same time difference
        itd = (0.0875 / 343.0) * (ang + math.sin(ang))                           # Woodworth head model
        near_fc, far_fc = 18000.0, 18000.0 * (1.0 - side) + 1800.0 * side
        rear = abs(az) > 90.0
        if rear:                                                                 # the ear shadows sound from behind
            near_fc, far_fc = near_fc * 0.5, far_fc * 0.55
        near_gain, far_gain = 1.0 + 0.3 * side, 1.0 - 0.35 * side
        if rear:
            near_gain, far_gain = near_gain * 0.9, far_gain * 0.9
        base = 6.0 / self.rate
        near = self.ear(base, near_fc, near_gain)
        far = self.ear(base + itd, far_fc, far_gain)
        return (far, near) if az > 0 else (near, far) if az < 0 else (near, near)   # (left ear, right ear)

    def process(self, left, right):
        n = len(left)
        centre = (left + right) * 0.5
        side = (left - right) * 0.5
        ext = np.concatenate([self.sbuf, side])
        rl = ext[self.dmax - self.d1:self.dmax - self.d1 + n]
        rr = -ext[self.dmax - self.d2:self.dmax - self.d2 + n]
        self.sbuf = ext[-self.dmax:].copy()
        feeds = {"FL": left - 0.5 * centre, "FR": right - 0.5 * centre, "C": centre, "RL": rl, "RR": rr}
        out_l = np.zeros(n, np.float32)
        out_r = np.zeros(n, np.float32)
        keep = self.TAPS - 1
        for name, _ in self.SPEAKERS:
            x = np.concatenate([self.hist[name], feeds[name].astype(np.float32)])
            self.hist[name] = x[-keep:].copy()
            h_left, h_right = self.irs[name]
            g = self.GAINS[name]
            out_l += g * np.convolve(x, h_left, "valid")[:n].astype(np.float32)
            out_r += g * np.convolve(x, h_right, "valid")[:n].astype(np.float32)
        return out_l, out_r


class _GUID(c.Structure):
    _fields_ = [("a", c.c_uint32), ("b", c.c_uint16), ("c", c.c_uint16), ("d", c.c_ubyte * 8)]


def _guid(text):
    u = uuid.UUID(text)
    return _GUID(u.time_low, u.time_mid, u.time_hi_version, (c.c_ubyte * 8)(*u.bytes[8:]))


class _PE32(c.Structure):
    _fields_ = [("dwSize", c.c_uint32), ("cntUsage", c.c_uint32), ("th32ProcessID", c.c_uint32),
                ("th32DefaultHeapID", c.c_size_t), ("th32ModuleID", c.c_uint32), ("cntThreads", c.c_uint32),
                ("th32ParentProcessID", c.c_uint32), ("pcPriClassBase", c.c_long), ("dwFlags", c.c_uint32),
                ("szExeFile", c.c_wchar * 260)]


def _processes():
    """{pid: (parent pid, exe name)}"""
    out = {}
    k32 = c.WinDLL("kernel32")
    k32.CreateToolhelp32Snapshot.restype = c.c_void_p
    k32.CreateToolhelp32Snapshot.argtypes = [c.c_uint32, c.c_uint32]
    k32.Process32FirstW.argtypes = [c.c_void_p, c.POINTER(_PE32)]
    k32.Process32NextW.argtypes = [c.c_void_p, c.POINTER(_PE32)]
    k32.CloseHandle.argtypes = [c.c_void_p]
    snap = k32.CreateToolhelp32Snapshot(2, 0)
    if not snap or snap == (1 << (8 * c.sizeof(c.c_void_p))) - 1:
        return out
    entry = _PE32()
    entry.dwSize = c.sizeof(_PE32)
    ok = k32.Process32FirstW(snap, c.byref(entry))
    while ok:
        out[entry.th32ProcessID] = (entry.th32ParentProcessID, entry.szExeFile)
        ok = k32.Process32NextW(snap, c.byref(entry))
    k32.CloseHandle(snap)
    return out


def _window_pids():
    """pids that own a visible window with a title (= the apps you can see)."""
    u32 = c.WinDLL("user32")
    enum_t = c.WINFUNCTYPE(c.c_int, c.c_void_p, c.c_void_p)
    u32.IsWindowVisible.argtypes = [c.c_void_p]
    u32.GetWindowTextLengthW.argtypes = [c.c_void_p]
    u32.GetWindowThreadProcessId.argtypes = [c.c_void_p, c.POINTER(c.c_uint32)]
    u32.EnumWindows.argtypes = [enum_t, c.c_void_p]
    pids = set()

    def visit(hwnd, _lparam):
        if u32.IsWindowVisible(hwnd) and u32.GetWindowTextLengthW(hwnd) > 0:
            pid = c.c_uint32()
            u32.GetWindowThreadProcessId(hwnd, c.byref(pid))
            pids.add(pid.value)
        return 1

    callback = enum_t(visit)
    u32.EnumWindows(callback, 0)
    return pids


def list_app_names():
    if os.name != "nt":
        return []
    try:
        procs = _processes()
        names = {procs[pid][1] for pid in _window_pids() if pid in procs and pid != os.getpid()
                 and procs[pid][1].lower() not in HIDE_APPS}
        return sorted(names, key=str.lower)
    except Exception:
        return []


def find_root_pid(exe):
    """The top process of an app (Chrome has many chrome.exe: the capture must start from the first one)."""
    if os.name != "nt":
        return 0
    try:
        procs = _processes()
        low = exe.lower()
        same = [pid for pid, (_ppid, name) in procs.items() if name.lower() == low]
        roots = [pid for pid in same if procs.get(procs[pid][0], (0, ""))[1].lower() != low]
        seen = _window_pids()
        roots.sort(key=lambda pid: (pid not in seen, pid))
        return (roots or same or [0])[0]
    except Exception:
        return 0


_STD = getattr(c, "WINFUNCTYPE", c.CFUNCTYPE)


def _vcall(obj, index, argtypes, *args):
    """Calls method number `index` of a raw COM object."""
    vtbl = c.cast(c.c_void_p(obj), c.POINTER(c.c_void_p))[0]
    table = c.cast(c.c_void_p(vtbl), c.POINTER(c.c_void_p))
    return _STD(c.c_long, c.c_void_p, *argtypes)(table[index])(obj, *args)


class _Blob(c.Structure):
    _fields_ = [("cbSize", c.c_uint32), ("pBlobData", c.c_void_p)]


class _PropVariant(c.Structure):
    _fields_ = [("vt", c.c_uint16), ("r1", c.c_uint16), ("r2", c.c_uint16), ("r3", c.c_uint16), ("blob", _Blob)]


class _LoopbackParams(c.Structure):
    _fields_ = [("ActivationType", c.c_int32), ("TargetProcessId", c.c_uint32), ("ProcessLoopbackMode", c.c_int32)]


class _WaveFormat(c.Structure):
    _pack_ = 1
    _fields_ = [("tag", c.c_uint16), ("channels", c.c_uint16), ("rate", c.c_uint32), ("bytes_per_sec", c.c_uint32),
                ("align", c.c_uint16), ("bits", c.c_uint16), ("extra", c.c_uint16)]


class _ComObject(c.Structure):
    _fields_ = [("vtbl", c.c_void_p)]


class AppCapture:
    """Captures everything ONE app (and its child processes) plays and pushes it into a Pipe."""

    def __init__(self, pid, rate, pipe, report):
        self.pid, self.rate, self.pipe, self.report = pid, rate, pipe, report
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)

    def start(self):
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        self.thread.join(timeout=2.0)

    def alive(self):
        return self.thread.is_alive()

    def _run(self):
        ole32 = c.WinDLL("ole32")
        ole32.CoInitializeEx.argtypes = [c.c_void_p, c.c_uint32]
        ole32.CoInitializeEx(None, 0)                       # multithreaded apartment
        held = []
        try:
            self._capture(held)
        except Exception as error:
            self.report("App capture stopped: %s" % error)
        finally:
            for obj in reversed(held):
                try:
                    _vcall(obj, 2, [])                      # Release
                except Exception:
                    pass
            try:
                ole32.CoUninitialize()
            except Exception:
                pass

    def _capture(self, held):
        k32 = c.WinDLL("kernel32")
        mm = c.WinDLL("mmdevapi")
        k32.CreateEventW.restype = c.c_void_p
        k32.CreateEventW.argtypes = [c.c_void_p, c.c_int, c.c_int, c.c_wchar_p]
        k32.WaitForSingleObject.argtypes = [c.c_void_p, c.c_uint32]
        mm.ActivateAudioInterfaceAsync.restype = c.c_long
        mm.ActivateAudioInterfaceAsync.argtypes = [c.c_wchar_p, c.POINTER(_GUID), c.POINTER(_PropVariant), c.c_void_p,
                                                   c.POINTER(c.c_void_p)]
        iid_client = _guid("1CB9AD4C-DBFA-4c32-B178-C2F568A703B2")
        iid_capture = _guid("C8ADBD64-E71E-48a0-A4DE-185C395CD317")
        known = [bytes(_guid(g)) for g in ("00000000-0000-0000-C000-000000000046",      # IUnknown
                                          "41D949AB-9862-444A-80F6-C261334DA5EB",      # completion handler
                                          "94ea2b94-e9cc-49e0-c0ff-ee64ca8f5b90")]     # IAgileObject
        done = threading.Event()

        def query_interface(this, riid, out):
            if bytes(riid.contents) in known:
                out[0] = this
                return 0
            out[0] = None
            return -2147467262                                  # E_NOINTERFACE

        def add_ref(_this):
            return 1

        def release(_this):
            return 1

        def completed(_this, _operation):
            done.set()
            return 0

        funcs = (c.CFUNCTYPE(c.c_long, c.c_void_p, c.POINTER(_GUID), c.POINTER(c.c_void_p))(query_interface),
                 c.CFUNCTYPE(c.c_ulong, c.c_void_p)(add_ref),
                 c.CFUNCTYPE(c.c_ulong, c.c_void_p)(release),
                 c.CFUNCTYPE(c.c_long, c.c_void_p, c.c_void_p)(completed))
        vtbl = (c.c_void_p * 4)(*[c.cast(f, c.c_void_p).value for f in funcs])
        handler = _ComObject(c.addressof(vtbl))

        params = _LoopbackParams(1, self.pid, 0)             # PROCESS_LOOPBACK, include the target + its child processes
        variant = _PropVariant()
        variant.vt = 0x41                                    # VT_BLOB
        variant.blob.cbSize = c.sizeof(params)
        variant.blob.pBlobData = c.addressof(params)
        operation = c.c_void_p()
        hr = mm.ActivateAudioInterfaceAsync("VAD\\Process_Loopback", c.byref(iid_client), c.byref(variant),
                                            c.addressof(handler), c.byref(operation))
        if hr < 0:
            raise RuntimeError("Windows refused (0x%08X). This needs Windows 10 version 2004 or newer." % (hr & 0xFFFFFFFF))
        held.append(operation.value)
        if not done.wait(5.0):
            raise RuntimeError("Windows did not answer")
        result, unknown = c.c_long(), c.c_void_p()
        _vcall(operation.value, 3, [c.POINTER(c.c_long), c.POINTER(c.c_void_p)], c.byref(result), c.byref(unknown))
        if result.value < 0 or not unknown.value:
            raise RuntimeError("could not attach to the app (0x%08X)" % (result.value & 0xFFFFFFFF))
        held.append(unknown.value)
        client = c.c_void_p()
        _vcall(unknown.value, 0, [c.POINTER(_GUID), c.POINTER(c.c_void_p)], c.byref(iid_client), c.byref(client))
        held.append(client.value)

        tag = bits = 0
        hr = -1
        for tag, bits in ((3, 32), (1, 16)):                 # float first, 16-bit as a fallback
            fmt = _WaveFormat(tag, 2, self.rate, self.rate * 2 * bits // 8, 2 * bits // 8, bits, 0)
            flags = 0x00020000 | 0x00040000 | 0x80000000 | 0x08000000   # loopback | event | auto-convert | good SRC
            hr = _vcall(client.value, 3, [c.c_int, c.c_uint32, c.c_int64, c.c_int64, c.POINTER(_WaveFormat), c.c_void_p],
                        0, flags, 2000000, 0, c.byref(fmt), None)
            if hr >= 0:
                break
        if hr < 0:
            raise RuntimeError("could not start the capture (0x%08X)" % (hr & 0xFFFFFFFF))
        event = k32.CreateEventW(None, 0, 0, None)
        _vcall(client.value, 13, [c.c_void_p], event)        # SetEventHandle
        capture = c.c_void_p()
        _vcall(client.value, 14, [c.POINTER(_GUID), c.POINTER(c.c_void_p)], c.byref(iid_capture), c.byref(capture))
        if not capture.value:
            raise RuntimeError("no capture service")
        held.append(capture.value)
        _vcall(client.value, 10, [])                         # Start
        self.report("")
        try:
            while not self.stop_event.is_set():
                k32.WaitForSingleObject(event, 40)
                while not self.stop_event.is_set():
                    size = c.c_uint32()
                    if _vcall(capture.value, 5, [c.POINTER(c.c_uint32)], c.byref(size)) < 0:
                        raise RuntimeError("the app closed or the sound device changed")
                    if size.value == 0:
                        break
                    data, frames, flag = c.c_void_p(), c.c_uint32(), c.c_uint32()
                    hr = _vcall(capture.value, 3, [c.POINTER(c.c_void_p), c.POINTER(c.c_uint32), c.POINTER(c.c_uint32),
                                                   c.c_void_p, c.c_void_p], c.byref(data), c.byref(frames), c.byref(flag), None, None)
                    if hr < 0:
                        raise RuntimeError("read error (0x%08X)" % (hr & 0xFFFFFFFF))
                    count = frames.value
                    block = None
                    if count:
                        if (flag.value & 2) or not data.value:
                            block = np.zeros((count, 2), np.float32)
                        elif tag == 3:
                            block = np.frombuffer(c.string_at(data.value, count * 8), np.float32).reshape(-1, 2).copy()
                        else:
                            block = np.frombuffer(c.string_at(data.value, count * 4), np.int16).reshape(-1, 2).astype(np.float32) / 32768.0
                    _vcall(capture.value, 4, [c.c_uint32], count)         # ReleaseBuffer
                    if block is not None:
                        self.pipe.push(block)
        finally:
            try:
                _vcall(client.value, 11, [])                 # Stop
            except Exception:
                pass


def find_dll():
    name = "ReverbPresets64.dll" if struct.calcsize("P") == 8 else "ReverbPresets32.dll"
    for folder in (HERE, os.getcwd()):
        path = os.path.join(folder, name)
        if os.path.exists(path):
            return path
    raise FileNotFoundError("%s was not found next to the program" % name)



# =============================================================================
#  Window  -  Creative "EAX Settings" look.  Only the SKIN / GUI lives below this line;
#  the audio engine above (Plugin / Console / Pipe) and the start/stop code are unchanged.
# =============================================================================
import math

SKIN = os.path.join(HERE, "skin")
FONT = ("Tahoma", -11)            # pixel sizes: the skin is a fixed-size bitmap, so the text must not follow Windows scaling
FONT_B = ("Tahoma", -11, "bold")
FONT_S = ("Tahoma", -10)
INK = "#3c3c3c"
PAGES = {"fx": (494, 342), "fx2": (494, 342), "mix": (494, 342), "cmss": (494, 342), "clean": (494, 342), "audio": (494, 342), "eq": (495, 309)}
KEY = "#ff00fe"                                  # see-through colour of the rounded corners (Windows)
CARDS = ["SB Live! 24-bit External", "SB Live! 64-bit External"]
NAV = [("icon_fx", "fx"), ("icon_eq", "eq")]
# extra pages (they only move; they do not touch the audio)
EXTRA = {
    "mix": {"title": "Surround Mixer", "kind": "v", "names": ["Volume", "Bass", "Treble", "Wave", "MIDI Synth", "CD Player", "Line-In"], "check": None},
    "cmss": {"title": "CMSS 3D", "kind": "h", "names": ["Front", "Center", "Rear"], "check": "Enable CMSS 3D"},
    "clean": {"title": "Clean-up", "kind": "h", "names": ["Noise Removal", "Click Removal", "Source Level"], "check": "Enable Audio Clean-up"},
}

# list box on the Effects page
LIST_BOX = (174, 186, 344, 291)
LIST_ROW, LIST_VISIBLE, LIST_TOP = 17, 6, 188
# Effects Amount slider (track in the skin: x 364..454)
AMT_X0, AMT_X1, AMT_Y = 364, 454, 175         # the thumb is 18 px wide and stays inside this track
THUMB_W = 18
# Equalizer sliders (coordinates of the equalizer picture)
EQ_X = [77, 124, 171, 217, 263, 309, 354]       # centre of every band track
EQ_PANEL = [(x - 18, x + 16) for x in EQ_X]
EQ_Y12, EQ_Y_12 = 124, 233                      # knob centre at +12 dB / -12 dB
LV_X, LV_Y0, LV_Y24 = 455, 132, 226             # Level slider: x, 0 dB, -24 dB
COMBO_BOX = (260, 67, 416, 91)
# Effects > Voice & App page
FX2_DEFAULT = {"speed_on": False, "speed": 50.0, "rev_on": False, "rev": 36.0, "vol": 50.0, "apply": "both", "src": "None"}
APPLY_CHOICES = (("voice", "My Voice"), ("app", "App Audio"), ("both", "Both"))
SPEED_ROW, REV_ROW, VOL_ROW, APPLY_ROW, SRC_ROW = 96, 140, 184, 216, 257
# Master volume knob (SB0490 style): press L = up, K = down, an on-screen indicator shows the level
VOL_STEPS = 8                                   # number of clicks of the knob (0 = mute ... VOL_STEPS = loudest)
VOL_UNITY = 4                                   # the click where the sound is exactly the original (where it starts)
VOL_DB_STEP = 6.0                               # every click above it adds this many dB (4 clicks x 6 = +24 dB), below it lowers it
VOL_KEY_UP, VOL_KEY_DOWN = "l", "k"             # the keys (on Windows the physical key is used, so Arabic layout works too)
VOL_VK_UP, VOL_VK_DOWN = 76, 75                 # Windows virtual-key codes of L / K
S3D_KEY, S3D_VK = "g", 71                       # press G = CMSS 3D (virtual surround) on / off
OSD_SHOW_MS, OSD_FADE_MS = 1400, 300
OSD_W, OSD_H, OSD_BOTTOM = 360, 78, 110         # size of the indicator and its distance from the bottom of the screen
SAVE_BTN_X = (290, 354)                         # the Save button in the footer (free space between the icons and the Creative logo)


class App:
    def __init__(self, root):
        import tkinter as tk
        from tkinter import ttk, messagebox
        import tkinter.font as tkfont
        self.tk, self.ttk, self.messagebox = tk, ttk, messagebox
        self.root = root
        root.title("EAX Reverb")
        self.saved = {}
        self._save_job, self._last_saved, self.flash = None, None, False
        found = [p for p in SETTINGS_PATHS if os.path.exists(p)]
        for path in sorted(found, key=os.path.getmtime, reverse=True):      # newest file first, next one if it is damaged
            try:
                with open(path, "r", encoding="utf-8") as f:
                    self.saved = json.load(f)
                break
            except Exception:
                continue
        try:
            self.plugin = Plugin(path=find_dll())
        except Exception as error:
            messagebox.showerror("EAX Reverb", "Could not load the reverb DLL:\n%s" % error)
            root.destroy()
            raise SystemExit(1)
        self.console = Console(self.plugin)
        self.stream = None
        self.pipe = None
        self.rate = 48000
        self.amounts = [float(a) for a in self.saved.get("amounts", [p[1] for p in PRESETS])]
        if len(self.amounts) != 15:
            self.amounts = [p[1] for p in PRESETS]
        self.preset = int(self.saved.get("preset", DEFAULT_PRESET)) % 15
        self.bands = [float(v) for v in self.saved.get("bands", [0] * 7)]
        self.bands = (self.bands + [0.0] * 7)[:7]
        self.level = float(self.saved.get("level", 0.0))
        self.reverb_on = bool(self.saved.get("reverb_on", True))
        self.eq_on = bool(self.saved.get("eq_on", False))
        self.font = tkfont.Font(family="Tahoma", size=-11)
        # voice speed / reverse / app source (Effects > Voice & App)
        self.v2 = dict(FX2_DEFAULT)
        for key, default in FX2_DEFAULT.items():
            try:
                value = (self.saved.get("fx2") or {}).get(key, default)
                self.v2[key] = type(default)(value)
            except Exception:
                self.v2[key] = default
        if self.v2["apply"] not in dict(APPLY_CHOICES):
            self.v2["apply"] = "both"
        self.shifter = self.reverser = None
        self.sp_active = self.rev_active = False
        self.app_pipe = self.app_cap = self.app_stream = None
        self.app_msg, self.retry_tick, self.cfg = "", 0, {}

        self.imgs = {}
        try:
            for name in ("effects_bg", "eq_bg", "page_bg", "knob_v", "knob_h", "thumb_h", "icon_fx", "icon_mix", "icon_cmss",
                         "icon_clean", "icon_eq", "chk_fx_on", "chk_fx_off", "chk_eq_on", "chk_eq_off"):
                self.imgs[name] = tk.PhotoImage(file=os.path.join(SKIN, name + ".png"))
        except Exception as error:
            messagebox.showerror("EAX Reverb", "The 'skin' folder is missing or damaged:\n%s" % error)
            root.destroy()
            raise SystemExit(1)

        self.card = self.saved.get("card") if self.saved.get("card") in CARDS else CARDS[1]
        self.misc = {key: {"on": False, "vals": [50.0] * len(d["names"])} for key, d in EXTRA.items()}
        for key, d in EXTRA.items():                    # restore the (decorative) pages too
            try:
                old = self.saved["misc"][key]
                if len(old["vals"]) == len(d["names"]):
                    self.misc[key] = {"on": bool(old["on"]), "vals": [float(v) for v in old["vals"]]}
            except Exception:
                pass
        self.page = "fx"
        self.list_top = 0
        self.hot, self.drag, self.popup, self.popup_hover = [], None, None, -1
        self.cv = tk.Canvas(root, width=PAGES["fx"][0], height=PAGES["fx"][1], bd=0, highlightthickness=0, bg=KEY)
        self.cv.pack()
        self.cv.bind("<ButtonPress-1>", self.on_press)
        self.cv.bind("<ButtonPress>", lambda e: self.root.focus_force(), add="+")
        self.cv.bind("<B1-Motion>", self.on_move)
        self.cv.bind("<ButtonRelease-1>", self.on_release)
        self.cv.bind("<Motion>", self.on_hover)
        self.cv.bind("<MouseWheel>", lambda e: self.on_wheel(e, -1 if e.delta > 0 else 1))
        self.cv.bind("<Button-4>", lambda e: self.on_wheel(e, -1))
        self.cv.bind("<Button-5>", lambda e: self.on_wheel(e, 1))

        self.make_vars()
        self.push_all()
        self.frameless()
        self.show("fx")
        root.protocol("WM_DELETE_WINDOW", self.close)
        self.init_volume()

    # ---------------------------------------------------------------- engine <-> state (unchanged behaviour)
    def push_all(self):
        for index, amount in enumerate(self.amounts):       # every preset keeps its own amount inside the DLL
            self.console.preset(index)
            self.console.amount(amount)
        self.console.preset(self.preset)
        self.console.enable(self.reverb_on)
        self.console.eq_enable(self.eq_on)
        for index, db in enumerate(self.bands):
            self.console.band(index, db)
        self.console.level(self.level)
        self.ensure_visible()
        if hasattr(self, "cv") and self.hot is not None and getattr(self, "bg_ready", False):
            self.render()

    def curve_name(self):
        now = [round(v) for v in self.bands]
        return next((n for n, g in CURVES if list(g) == now), "<Custom>")

    # ---------------------------------------------------------------- frameless window
    def frameless(self):
        self.root.overrideredirect(True)
        try:
            self.root.attributes("-transparentcolor", KEY)      # rounded corners
        except Exception:
            pass
        self.root.after(50, self.appwindow)
        self.root.after(120, self.round_corners)

    def corner_insets(self, image, w, h, depth=12):
        """How many pixels each of the first / last rows is cut at the left and the right (the key-colour corners of the skin)."""
        key = tuple(int(KEY[i:i + 2], 16) for i in (1, 3, 5))

        def inset(y, step, x0):
            x = x0
            for _ in range(w // 2):
                px = image.get(x, y)
                px = tuple(int(v) for v in (px.split() if isinstance(px, str) else px))
                if px != key:
                    break
                x += step
            return abs(x - x0)
        return [(inset(y, 1, 0), inset(y, -1, w - 1)) for y in list(range(depth)) + list(range(h - depth, h))]

    def round_corners(self):
        """Windows only: clips the real window to the rounded outline of the picture, so the corners are always round."""
        if os.name != "nt":
            return
        try:
            w, h = PAGES[self.page]
            image = self.imgs["effects_bg" if self.page == "fx" else "eq_bg" if self.page == "eq" else "page_bg"]
            insets = self.corner_insets(image, w, h)
            depth = len(insets) // 2
            user32, gdi32 = ctypes.windll.user32, ctypes.windll.gdi32
            gdi32.CreateRectRgn.restype = c.c_void_p
            gdi32.CreateRectRgn.argtypes = [c.c_int] * 4
            gdi32.CombineRgn.argtypes = [c.c_void_p, c.c_void_p, c.c_void_p, c.c_int]
            gdi32.DeleteObject.argtypes = [c.c_void_p]
            user32.SetWindowRgn.argtypes = [c.c_void_p, c.c_void_p, c.c_int]
            rects = [(0, depth, w, h - depth)]
            for k, (left, right) in enumerate(insets):
                y = k if k < depth else h - 2 * depth + k
                rects.append((left, y, w - right, y + 1))
            region = gdi32.CreateRectRgn(0, 0, 0, 0)
            for x0, y0, x1, y1 in rects:
                piece = gdi32.CreateRectRgn(x0, y0, x1, y1)
                gdi32.CombineRgn(region, region, piece, 2)          # RGN_OR
                gdi32.DeleteObject(piece)
            hwnd = user32.GetParent(self.root.winfo_id()) or self.root.winfo_id()
            user32.SetWindowRgn(hwnd, region, True)                 # Windows owns the region from here on
        except Exception:
            pass

    def appwindow(self):
        """Keeps a taskbar button for a window without a title bar (Windows only)."""
        if os.name != "nt":
            return
        try:
            user32 = ctypes.windll.user32
            hwnd = user32.GetParent(self.root.winfo_id()) or self.root.winfo_id()
            style = user32.GetWindowLongW(hwnd, -20)
            user32.SetWindowLongW(hwnd, -20, (style & ~0x80) | 0x40000)
            self.root.withdraw()
            self.root.after(20, self.root.deiconify)
        except Exception:
            pass

    def minimize(self):
        if os.name == "nt":
            self.root.overrideredirect(False)
            self.root.iconify()
            self.root.bind("<Map>", self.unminimized)
        else:
            self.root.iconify()

    def unminimized(self, event):
        if event.widget is self.root and self.root.state() == "normal":
            self.root.unbind("<Map>")
            self.root.overrideredirect(True)
            try:
                self.root.attributes("-transparentcolor", KEY)
            except Exception:
                pass
            self.root.after(50, self.appwindow)
            self.root.after(120, self.round_corners)

    # ---------------------------------------------------------------- audio settings (state only - drawn on the "audio" page)
    def make_vars(self):
        tk = self.tk
        self.hosts = sd.query_hostapis() if sd else []
        host_names = [h["name"] for h in self.hosts]
        self.host_var = tk.StringVar()
        self.in_var = tk.StringVar()
        self.out_var = tk.StringVar()
        if self.saved.get("ver", 1) < SETTINGS_VERSION:
            self.saved["block"] = BLOCK
        self.block_var = tk.StringVar(value=str(self.saved.get("block", BLOCK)))
        if self.block_var.get() not in BLOCK_CHOICES:
            self.block_var.set(str(BLOCK))
        self.start_text = tk.StringVar(value="Start")
        self.status = tk.StringVar(value="Stopped")
        wanted = self.saved.get("host")
        pick = wanted if wanted in host_names else next((n for n in host_names if "WASAPI" in n), host_names[0] if host_names else "")
        self.host_var.set(pick)
        self.fill_devices()

    def fill_devices(self):
        self.ins, self.outs = [], []
        if not sd:
            return
        host = self.host_var.get()
        index = next((i for i, h in enumerate(self.hosts) if h["name"] == host), None)
        devices = sd.query_devices()
        self.ins = [(i, d["name"]) for i, d in enumerate(devices) if d["hostapi"] == index and d["max_input_channels"] > 0]
        self.outs = [(i, d["name"]) for i, d in enumerate(devices) if d["hostapi"] == index and d["max_output_channels"] > 0]
        for var, items, key in ((self.in_var, self.ins, "input"), (self.out_var, self.outs, "output")):
            names = [n for _, n in items]
            wanted = self.saved.get(key)
            var.set(wanted if wanted in names else (names[0] if names else ""))

    # ---------------------------------------------------------------- drawing
    def show(self, page):
        self.page = page
        w, h = PAGES[page]
        self.popup = None
        self.cv.configure(width=w, height=h)
        self.root.geometry("%dx%d" % (w, h))
        self.cv.delete("all")
        self.cv.create_image(0, 0, image=self.imgs["effects_bg" if page == "fx" else "eq_bg" if page == "eq" else "page_bg"], anchor="nw")
        self.bg_ready = True
        self.build_hot()
        self.render()
        if getattr(self, "_rounded_for", None) != page:
            self._rounded_for = page
            self.root.after(30, self.round_corners)

    def render(self):
        cv = self.cv
        cv.delete("dyn")
        self.schedule_save()
        self.draw_header()
        if self.page == "fx":
            self.draw_effects()
        elif self.page == "fx2":
            self.draw_fx2()
        elif self.page == "eq":
            self.draw_equalizer()
        elif self.page == "audio":
            self.draw_audio()
        else:
            self.draw_extra()
        self.draw_footer()
        self.draw_popup()

    def ellipsize(self, text, width):
        if self.font.measure(text) <= width:
            return text
        while text and self.font.measure(text + "...") > width:
            text = text[:-1]
        return text + "..."

    def draw_header(self):
        cv = self.cv
        dy = -2 if self.page == "eq" else 0
        running = self.stream is not None
        cv.create_text(202, 15 + dy, text=self.card, anchor="w", font=FONT, fill=INK, tags="dyn")
        # start / stop glyph where the "?" button was
        cx, cy = 386, 15 + dy
        if running:
            cv.create_rectangle(cx - 5, cy - 5, cx + 5, cy + 5, fill="#1e5fbf", outline="#123f85", tags="dyn")
        else:
            cv.create_polygon(cx - 4, cy - 6, cx - 4, cy + 6, cx + 6, cy, fill="#1e5fbf", outline="#123f85", tags="dyn")

    def draw_check(self, x, y, on, kind):
        self.cv.create_image(x, y, image=self.imgs["chk_%s_%s" % (kind, "on" if on else "off")], anchor="nw", tags="dyn")

    def draw_footer(self):
        cv = self.cv
        y = 285 if self.page == "eq" else 318
        for slot, (name, page) in enumerate(NAV):
            x = 116 + 32 * slot
            if page == self.page or (page == "fx" and self.page == "fx2"):
                cv.create_rectangle(x - 3, y - 3, x + 24, y + 24, outline="#2a6fd0", width=2, tags="dyn")
            cv.create_image(x, y, image=self.imgs[name], anchor="nw", tags="dyn")

    # ----- Effects page
    def draw_effects(self):
        cv = self.cv
        self.draw_check(12, 119, self.reverb_on, "fx")
        cv.create_text(174, 176, text=PRESETS[self.preset][0], anchor="w", font=FONT, fill=INK, tags="dyn")
        cv.create_text(431, 158, text=str(round(self.amounts[self.preset])), anchor="w", font=FONT, fill=INK, tags="dyn")
        x0, y0, x1, y1 = LIST_BOX
        cv.create_rectangle(x0 + 1, y0 + 1, x1 - 1, y1 - 1, outline="#7b7b7b", width=2, fill="#ffffff", tags="dyn")
        for row in range(LIST_VISIBLE):
            index = self.list_top + row
            if index >= len(PRESETS):
                break
            top = LIST_TOP + row * LIST_ROW
            if index == self.preset:
                cv.create_rectangle(x0 + 2, top, x1 - 20, top + LIST_ROW, fill="#0a6ccf", outline="", tags="dyn")
            cv.create_text(x0 + 8, top + LIST_ROW // 2, text=PRESETS[index][0], anchor="w", font=FONT,
                           fill="#ffffff" if index == self.preset else INK, tags="dyn")
        sx0, sy0, sx1, sy1 = self.scroll_box()
        cv.create_rectangle(sx0, sy0, sx1, sy1, fill="#f1f1f1", outline="", tags="dyn")
        ty0, ty1 = self.thumb()
        cv.create_rectangle(sx0 + 6, ty0, sx0 + 11, ty1, fill="#8a8a8a", outline="", tags="dyn")
        kx = AMT_X0 + THUMB_W / 2.0 + (AMT_X1 - AMT_X0 - THUMB_W) * self.amounts[self.preset] / 100.0
        cv.create_image(round(kx), AMT_Y, image=self.imgs["thumb_h"], tags="dyn")

    def scroll_box(self):
        x0, y0, x1, y1 = LIST_BOX
        return x1 - 19, LIST_TOP, x1 - 2, y1 - 2

    def thumb(self):
        sx0, sy0, sx1, sy1 = self.scroll_box()
        track = sy1 - sy0
        size = max(16, track * LIST_VISIBLE // len(PRESETS))
        span = len(PRESETS) - LIST_VISIBLE
        top = sy0 + (track - size) * (self.list_top / float(span) if span else 0.0)
        return int(top), int(top + size)

    def ensure_visible(self):
        if self.preset < self.list_top:
            self.list_top = self.preset
        elif self.preset >= self.list_top + LIST_VISIBLE:
            self.list_top = self.preset - LIST_VISIBLE + 1
        self.list_top = max(0, min(len(PRESETS) - LIST_VISIBLE, self.list_top))

    # ----- Equalizer page
    @staticmethod
    def band_y(db):
        return EQ_Y12 + (12.0 - db) / 24.0 * (EQ_Y_12 - EQ_Y12)

    @staticmethod
    def level_y(db):
        return LV_Y0 + (-db) / 24.0 * (LV_Y24 - LV_Y0)

    def draw_equalizer(self):
        cv = self.cv
        self.draw_check(6, 70, self.eq_on, "eq")
        x0, y0, x1, y1 = COMBO_BOX
        cv.create_text(x0 + 8, (y0 + y1) // 2, text=self.curve_name(), anchor="w", font=FONT, fill=INK, tags="dyn")
        for i, db in enumerate(self.bands):
            cv.create_text(EQ_X[i], 94, text="%+d" % round(db) if round(db) else "0", font=FONT_S, fill="#555555", tags="dyn")
            cv.create_image(EQ_X[i], round(self.band_y(db)), image=self.imgs["knob_v"], tags="dyn")
        cv.create_text(LV_X, 108, text="%d dB" % round(self.level), font=FONT_S, fill="#555555", tags="dyn")
        cv.create_image(LV_X, round(self.level_y(self.level)), image=self.imgs["knob_v"], tags="dyn")

    # ---------------------------------------------------------------- pop-up lists (drawn inside the same window)
    def open_popup(self, field, items, current, pick, rows=8):
        x0, y0, x1, y1 = field
        row = 17
        vis = max(1, min(rows, len(items)))
        height = vis * row + 4
        top = y1 if y1 + height <= PAGES[self.page][1] - 2 else max(2, y0 - height)
        cur = items.index(current) if current in items else -1
        first = max(0, min(len(items) - vis, cur - vis // 2)) if cur >= 0 else 0
        self.popup = {"box": (x0, top, x1, top + height), "items": list(items), "row": row, "vis": vis,
                      "first": first, "hover": -1, "cur": cur, "pick": pick}
        self.render()

    def popup_index(self, e):
        p = self.popup
        x0, y0, x1, y1 = p["box"]
        if x0 <= e.x < x1 and y0 + 2 <= e.y < y1 - 2:
            index = p["first"] + (e.y - y0 - 2) // p["row"]
            if p["first"] <= index < min(len(p["items"]), p["first"] + p["vis"]):
                return index
        return -1

    def draw_popup(self):
        p = self.popup
        if not p:
            return
        cv = self.cv
        x0, y0, x1, y1 = p["box"]
        cv.create_rectangle(x0, y0, x1, y1, fill="#ffffff", outline="#7b7b7b", tags="dyn")
        mark = p["hover"] if p["hover"] >= 0 else p["cur"]
        for row in range(p["vis"]):
            index = p["first"] + row
            top = y0 + 2 + row * p["row"]
            if index == mark:
                cv.create_rectangle(x0 + 1, top, x1 - 1, top + p["row"], fill="#0a6ccf", outline="", tags="dyn")
            cv.create_text(x0 + 8, top + p["row"] // 2, text=self.ellipsize(p["items"][index], x1 - x0 - 24), anchor="w", font=FONT,
                           fill="#ffffff" if index == mark else INK, tags="dyn")
        if len(p["items"]) > p["vis"]:
            span = y1 - y0 - 4
            size = max(12, span * p["vis"] // len(p["items"]))
            ty = y0 + 2 + (span - size) * p["first"] // max(1, len(p["items"]) - p["vis"])
            cv.create_rectangle(x1 - 7, ty, x1 - 3, ty + size, fill="#8a8a8a", outline="", tags="dyn")

    def open_curves(self):
        self.open_popup(COMBO_BOX, [n for n, _ in CURVES], self.curve_name(), self.curve_chosen)

    # ---------------------------------------------------------------- Effects > Voice & App page
    @staticmethod
    def speed_ratio(v):                       # slider 0..100 -> x0.5 .. x2.0 (middle = x1.00)
        return 0.5 * 4.0 ** (v / 100.0)

    @staticmethod
    def rev_ms(v):                            # slider 0..100 -> 100 .. 800 ms
        return int(100 + v * 7)

    def draw_slider(self, y, label, text, value, on=None):
        cv = self.cv
        if on is not None:
            self.draw_check(14, y - 7, on, "fx")
            cv.create_text(36, y - 1, text=label, anchor="w", font=FONT, fill=INK, tags="dyn")
        else:
            cv.create_text(36, y - 1, text=label, anchor="w", font=FONT, fill=INK, tags="dyn")
        cv.create_text(36, y + 13, text=text, anchor="w", font=FONT_S, fill="#555555", tags="dyn")
        cv.create_text(150, y, text="-", font=FONT_B, fill=INK, tags="dyn")
        cv.create_text(452, y, text="+", font=FONT_B, fill=INK, tags="dyn")
        cv.create_rectangle(170, y - 2, 440, y + 3, fill="#6e6e6e", outline="#444444", tags="dyn")
        cv.create_image(round(179 + 252 * value / 100.0), y, image=self.imgs["thumb_h"], tags="dyn")

    def draw_fx2(self):
        cv, v = self.cv, self.v2
        self.draw_title("Effects  >  Voice & App")
        self.panel(4, 58, 490, 308)
        self.draw_slider(SPEED_ROW, "Voice Speed", "x%.2f" % self.speed_ratio(v["speed"]), v["speed"], v["speed_on"])
        self.draw_slider(REV_ROW, "Reverse Voice", "%d ms pieces" % self.rev_ms(v["rev"]), v["rev"], v["rev_on"])
        self.draw_slider(VOL_ROW, "App Volume", "%d%%" % round(v["vol"] * 2), v["vol"])
        cv.create_text(24, APPLY_ROW + 12, text="Reverb on", anchor="w", font=FONT, fill=INK, tags="dyn")
        for slot, (key, label) in enumerate(APPLY_CHOICES):
            x0, on = 110 + 86 * slot, v["apply"] == key
            cv.create_rectangle(x0, APPLY_ROW, x0 + 80, APPLY_ROW + 24, fill="#0a6ccf" if on else "#f6f6f6", outline="#555555", tags="dyn")
            cv.create_text(x0 + 40, APPLY_ROW + 12, text=label, font=FONT_B, fill="#ffffff" if on else INK, tags="dyn")
        cv.create_text(24, SRC_ROW + 11, text="App Source", anchor="w", font=FONT, fill=INK, tags="dyn")
        self.field(110, SRC_ROW, 380, v["src"])
        cv.create_rectangle(388, SRC_ROW, 470, SRC_ROW + 22, fill="#f6f6f6", outline="#555555", tags="dyn")
        cv.create_text(429, SRC_ROW + 11, text="Refresh", font=FONT_B, fill=INK, tags="dyn")
        note = self.app_msg or ("Reverb is applied to: %s" % dict(APPLY_CHOICES)[v["apply"]] if v["src"] != "None" else
                                "Pick an app (or a cable) in App Source to mix it in.")
        cv.create_text(24, 292, text=self.ellipsize(note, 440), anchor="w", font=FONT_S, fill="#555555", tags="dyn")

    def toggle_v2(self, key):
        self.v2[key] = not self.v2[key]
        self.render()

    def press_v2(self, key):
        def start(e):
            def move(ev):
                value = float(min(max((ev.x - 179) * 100.0 / 252.0, 0), 100))
                if key == "speed" and abs(value - 50.0) < 1.5:
                    value = 50.0                                 # snaps to x1.00
                self.v2[key] = value
                self.render()
            move(e)
            return move
        return start

    def set_apply(self, key):
        self.v2["apply"] = key
        self.render()

    def fx2_default(self):
        keep = self.v2["src"]
        self.v2 = dict(FX2_DEFAULT)
        self.v2["src"] = keep
        self.render()

    def open_app_list(self):
        items = ["None"] + ["App: " + n for n in list_app_names()] + ["Device: " + n for _, n in self.ins]
        self.open_popup((110, SRC_ROW, 380, SRC_ROW + 22), items, self.v2["src"], self.pick_app_src)

    def pick_app_src(self, name):
        self.v2["src"] = name
        self.app_msg = ""
        if self.stream is not None:
            self.start_app_source()
        self.render()

    def refresh_app(self):
        self.app_msg = ""
        if self.stream is not None:
            self.start_app_source()
        self.render()

    # ---------------------------------------------------------------- master volume knob + on-screen indicator
    @staticmethod
    def step_gain(step):
        return 0.0 if step <= 0 else 10.0 ** ((step - VOL_UNITY) * VOL_DB_STEP / 20.0)        # unity click = x1.0, above it = amplifier

    @staticmethod
    def step_db(step):
        return (step - VOL_UNITY) * VOL_DB_STEP

    def init_volume(self):
        try:
            step = int(self.saved.get("vol_knob", VOL_UNITY))
        except Exception:
            step = VOL_UNITY
        self.vol_step = max(0, min(VOL_STEPS, step))
        self.vol_gain = self.vol_prev = self.step_gain(self.vol_step)
        self.osd = self.osd_cv = None
        self.osd_kind = "vol"
        self.g_held = False
        self.root.bind_all("<KeyRelease>", self.g_release, add="+")
        self.s3d = None
        self.s3d_on = bool(self.saved.get("s3d_on", False))
        self.s3d_target = self.s3d_prev = 1.0 if self.s3d_on else 0.0
        self.osd_hide_job = self.osd_fade_job = None
        self.root.bind_all("<KeyPress>", self.on_volume_key, add="+")
        self.root.after(400, self.take_focus)

    def take_focus(self):
        try:
            self.root.focus_force()
        except Exception:
            pass

    def on_volume_key(self, e):
        if e.state & 0x4:                                   # Ctrl+L etc. are not the knob
            return
        key = (e.keysym or "").lower()
        code = getattr(e, "keycode", 0) if os.name == "nt" else 0
        if key == VOL_KEY_UP or code == VOL_VK_UP:
            self.volume_change(1)
        elif key == VOL_KEY_DOWN or code == VOL_VK_DOWN:
            self.volume_change(-1)
        elif key == S3D_KEY or code == S3D_VK:
            if not self.g_held:                              # holding the key must not flip it again and again
                self.s3d_toggle()
            self.g_held = True

    def g_release(self, e):
        key = (e.keysym or "").lower()
        if key == S3D_KEY or (os.name == "nt" and getattr(e, "keycode", 0) == S3D_VK):
            self.g_held = False

    def s3d_toggle(self):
        self.s3d_on = not self.s3d_on
        self.s3d_target = 1.0 if self.s3d_on else 0.0
        self.schedule_save()
        self.show_osd("3d")

    def volume_change(self, delta):
        self.vol_step = max(0, min(VOL_STEPS, self.vol_step + delta))
        self.vol_gain = self.step_gain(self.vol_step)       # the audio callback ramps to it
        self.schedule_save()
        self.show_osd("vol")

    def osd_create(self):
        tk = self.tk
        win = tk.Toplevel(self.root)
        win.overrideredirect(True)
        bg = KEY if os.name == "nt" else "#1b1d21"
        win.configure(bg=bg)
        try:
            win.attributes("-topmost", True)
            if os.name == "nt":
                win.attributes("-transparentcolor", KEY)
        except Exception:
            pass
        cv = tk.Canvas(win, width=OSD_W, height=OSD_H, bd=0, highlightthickness=0, bg=bg)
        cv.pack()
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        win.geometry("%dx%d+%d+%d" % (OSD_W, OSD_H, (sw - OSD_W) // 2, sh - OSD_H - OSD_BOTTOM))
        win.update_idletasks()
        if os.name == "nt":                                 # never takes focus, mouse clicks go through it
            try:
                user32 = ctypes.windll.user32
                hwnd = user32.GetParent(win.winfo_id()) or win.winfo_id()
                style = user32.GetWindowLongW(hwnd, -20)
                user32.SetWindowLongW(hwnd, -20, style | 0x08000000 | 0x80 | 0x20)
            except Exception:
                pass
        self.osd, self.osd_cv = win, cv

    def osd_draw(self):
        cv, step = self.osd_cv, self.vol_step
        cv.delete("all")
        r, W, H = 22, OSD_W, OSD_H
        pts = []
        for cx, cy, a0 in ((r, r, 180), (W - r, r, 270), (W - r, H - r, 0), (r, H - r, 90)):
            for k in range(0, 91, 10):
                ang = math.radians(a0 + k)
                pts += [cx + r * math.cos(ang), cy + r * math.sin(ang)]
        cv.create_polygon(pts, fill="#1b1d21", outline="#3b3f46", width=1)
        if self.osd_kind == "3d":
            cy = H // 2
            cx = 46
            cv.create_oval(cx - 8, cy - 8, cx + 8, cy + 8, fill="#cfd3d8", outline="")          # the head
            cv.create_polygon(cx - 3, cy - 8, cx, cy - 13, cx + 3, cy - 8, fill="#cfd3d8", outline="")
            for _name, az in Spatial3D.SPEAKERS:
                a = math.radians(az)
                col = "#ffb43a" if self.s3d_on else "#5a5f67"
                cv.create_oval(cx + 27 * math.sin(a) - 4, cy - 27 * math.cos(a) - 4, cx + 27 * math.sin(a) + 4, cy - 27 * math.cos(a) + 4, fill=col, outline="")
            cv.create_text(104, 18, text="CMSS 3D Headphone", fill="#9aa0a8", font=("Tahoma", -11), anchor="w")
            cv.create_text(104, cy + 8, text="3D Sound", fill="#ffffff", font=("Tahoma", -22, "bold"), anchor="w")
            cv.create_text(W - 24, cy + 8, text="ON" if self.s3d_on else "OFF", fill="#3ddc84" if self.s3d_on else "#8b9098", font=("Tahoma", -22, "bold"), anchor="e")
            return
        # speaker
        x, cy = 26, H // 2
        col = "#ffffff" if step else "#7d828a"
        cv.create_polygon(x, cy - 6, x + 9, cy - 6, x + 20, cy - 15, x + 20, cy + 15, x + 9, cy + 6, x, cy + 6, fill=col, outline=col)
        if step == 0:
            cv.create_line(x + 27, cy - 8, x + 41, cy + 8, fill="#ff5a4f", width=3)
            cv.create_line(x + 27, cy + 8, x + 41, cy - 8, fill="#ff5a4f", width=3)
        else:
            for i in range(1 + (step > VOL_STEPS // 3) + (step > 2 * VOL_STEPS // 3)):
                d = 7 + i * 7
                cv.create_arc(x + 22 - d, cy - d, x + 22 + d, cy + d, start=-45, extent=90, style="arc", outline=col, width=2)
        # segmented bar
        bx0, bx1, by, bh, gap = 86, W - 104, H // 2 - 9, 18, 4
        sw = (bx1 - bx0 - gap * (VOL_STEPS - 1)) / VOL_STEPS
        for i in range(VOL_STEPS):
            x0 = bx0 + i * (sw + gap)
            cv.create_rectangle(x0, by, x0 + sw, by + bh, fill=("#2f9bff" if i < VOL_UNITY else "#ffb43a") if i < step else "#3a3e45", outline="")
        cv.create_text(W - 52, H // 2, text="MUTE" if step == 0 else "%+d dB" % round(self.step_db(step)) if step != VOL_UNITY else "0 dB",
                       fill="#ffffff" if step <= VOL_UNITY else "#ffb43a", font=("Tahoma", -18, "bold"))
        cv.create_text(86, 14, text="Volume", fill="#9aa0a8", font=("Tahoma", -11), anchor="w")

    def show_osd(self, kind="vol"):
        self.osd_kind = kind
        try:
            if self.osd is None:
                self.osd_create()
            for job in (self.osd_hide_job, self.osd_fade_job):
                if job is not None:
                    self.root.after_cancel(job)
            self.osd_fade_job = None
            self.osd_draw()
            self.osd.attributes("-alpha", 0.95)
            self.osd.deiconify()
            self.osd.lift()
            self.osd_hide_job = self.root.after(OSD_SHOW_MS, self.osd_fade, 0)
        except Exception:
            pass

    def osd_fade(self, n):
        self.osd_hide_job = None
        try:
            steps = 10
            if n >= steps:
                self.osd.withdraw()
                self.osd_fade_job = None
                return
            self.osd.attributes("-alpha", 0.95 * (1 - (n + 1) / steps))
            self.osd_fade_job = self.root.after(OSD_FADE_MS // steps, self.osd_fade, n + 1)
        except Exception:
            pass

    # ---------------------------------------------------------------- save
    def snapshot(self):
        return {"preset": self.preset, "amounts": self.amounts, "bands": self.bands, "level": self.level,
                "reverb_on": self.reverb_on, "eq_on": self.eq_on, "host": self.host_var.get(),
                "input": self.in_var.get(), "output": self.out_var.get(), "block": int(self.block_var.get()),
                "card": self.card, "ver": SETTINGS_VERSION, "fx2": dict(self.v2), "vol_knob": self.vol_step, "s3d_on": self.s3d_on,
                "misc": {k: {"on": m["on"], "vals": list(m["vals"])} for k, m in self.misc.items()}}

    @staticmethod
    def write_settings(data):
        text, done = json.dumps(data, indent=1), False
        for path in SETTINGS_PATHS:
            try:
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path + ".tmp", "w", encoding="utf-8") as f:
                    f.write(text)
                os.replace(path + ".tmp", path)                  # never leaves a half-written file
                done = True
            except Exception:
                pass
        return done

    def schedule_save(self):
        if self._save_job is None:
            self._save_job = self.root.after(800, self.autosave)

    def autosave(self):
        self._save_job = None
        try:
            data = self.snapshot()
            if data != self._last_saved and self.write_settings(data):
                self._last_saved = data
        except Exception:
            pass

    def save_now(self):
        data = self.snapshot()
        if self.write_settings(data):
            self._last_saved = data
            self.flash = True
            self.root.after(1500, self.unflash)
        else:
            self.messagebox.showerror("EAX Reverb", "Could not write the settings file.")
        self.render()

    def unflash(self):
        self.flash = False
        self.render()

    # ---------------------------------------------------------------- extra pages (Mixer / CMSS / Clean-up) - they only move
    def panel(self, x0, y0, x1, y1, r=10, fill="#dadada"):
        pts = []
        for cx, cy, a0 in ((x1 - r, y0 + r, -90), (x1 - r, y1 - r, 0), (x0 + r, y1 - r, 90), (x0 + r, y0 + r, 180)):
            for k in range(0, 91, 15):
                ang = math.radians(a0 + k)
                pts += [cx + r * math.cos(ang), cy + r * math.sin(ang)]
        self.cv.create_polygon(pts, fill=fill, outline="", tags="dyn")

    def draw_title(self, text):
        self.cv.create_text(247, 44, text=text, font=FONT_B, fill=INK, tags="dyn")

    def draw_extra(self):
        cv = self.cv
        d, m = EXTRA[self.page], self.misc[self.page]
        self.draw_title(d["title"])
        if d["kind"] == "v":
            self.panel(4, 62, 490, 308)
            for i, name in enumerate(d["names"]):
                x = 44 + i * 67
                cv.create_rectangle(x - 2, 96, x + 2, 244, fill="#6e6e6e", outline="#444444", tags="dyn")
                cv.create_text(x, 78, text=str(round(m["vals"][i])), font=FONT_S, fill="#555555", tags="dyn")
                cv.create_image(x, round(238 - (238 - 100) * m["vals"][i] / 100.0), image=self.imgs["knob_v"], tags="dyn")
                cv.create_text(x, 268, text=name, font=FONT, fill=INK, tags="dyn")
        else:
            self.draw_check(14, 64, m["on"], "fx")
            cv.create_text(36, 72, text=d["check"], anchor="w", font=FONT, fill=INK, tags="dyn")
            self.panel(4, 96, 490, 308)
            for i, name in enumerate(d["names"]):
                y = 140 + i * 50
                cv.create_text(30, y, text=name, anchor="w", font=FONT, fill=INK, tags="dyn")
                cv.create_text(150, y, text="-", font=FONT_B, fill=INK, tags="dyn")
                cv.create_text(452, y, text="+", font=FONT_B, fill=INK, tags="dyn")
                cv.create_rectangle(170, y - 2, 440, y + 3, fill="#6e6e6e", outline="#444444", tags="dyn")
                cv.create_image(round(179 + 252 * m["vals"][i] / 100.0), y, image=self.imgs["thumb_h"], tags="dyn")

    def press_extra_v(self, i):
        def start(e):
            def move(ev):
                self.misc[self.page]["vals"][i] = float(min(max((238 - ev.y) * 100.0 / 138.0, 0), 100))
                self.render()
            move(e)
            return move
        return start

    def press_extra_h(self, i):
        def start(e):
            def move(ev):
                self.misc[self.page]["vals"][i] = float(min(max((ev.x - 179) * 100.0 / 252.0, 0), 100))
                self.render()
            move(e)
            return move
        return start

    def toggle_extra(self):
        m = self.misc[self.page]
        m["on"] = not m["on"]
        self.render()

    def extra_default(self):
        if self.page in self.misc:
            self.misc[self.page] = {"on": False, "vals": [50.0] * len(EXTRA[self.page]["names"])}
            self.render()

    # ---------------------------------------------------------------- audio page (devices / buffer / start) - same window, no extra window
    def field(self, x0, y, x1, text):
        cv = self.cv
        cv.create_rectangle(x0, y, x1, y + 22, fill="#ffffff", outline="#7b7b7b", tags="dyn")
        cv.create_text(x0 + 6, y + 11, text=self.ellipsize(text, x1 - x0 - 26), anchor="w", font=FONT, fill=INK, tags="dyn")
        cv.create_polygon(x1 - 15, y + 8, x1 - 7, y + 8, x1 - 11, y + 14, fill="#555555", outline="", tags="dyn")

    AUDIO_ROWS = (("Driver", 88), ("Input", 126), ("Output", 164), ("Buffer", 202))

    def draw_audio(self):
        cv = self.cv
        self.draw_title("Audio Setup")
        self.panel(4, 62, 490, 308)
        values = {"Driver": self.host_var.get(), "Input": self.in_var.get(), "Output": self.out_var.get(), "Buffer": self.block_var.get()}
        for label, y in self.AUDIO_ROWS:
            cv.create_text(24, y + 11, text=label, anchor="w", font=FONT, fill=INK, tags="dyn")
            self.field(90, y, 470 if label != "Buffer" else 190, values[label])
        cv.create_rectangle(90, 244, 190, 268, fill="#f6f6f6", outline="#555555", tags="dyn")
        cv.create_text(140, 256, text=self.start_text.get(), font=FONT_B, fill=INK, tags="dyn")
        cv.create_text(24, 290, text=self.status.get(), anchor="w", font=FONT, fill="#555555", tags="dyn")

    def pick_host(self, name):
        self.host_var.set(name)
        self.fill_devices()
        self.render()

    def pick_var(self, var):
        def pick(name):
            var.set(name)
            self.render()
        return pick

    def press_audio_field(self, label):
        def go(e):
            y = dict(self.AUDIO_ROWS)[label]
            box = (90, y, 470 if label != "Buffer" else 190, y + 22)
            if label == "Driver":
                self.open_popup(box, [h["name"] for h in self.hosts], self.host_var.get(), self.pick_host)
            elif label == "Input":
                self.open_popup(box, [n for _, n in self.ins], self.in_var.get(), self.pick_var(self.in_var))
            elif label == "Output":
                self.open_popup(box, [n for _, n in self.outs], self.out_var.get(), self.pick_var(self.out_var))
            else:
                self.open_popup(box, list(BLOCK_CHOICES), self.block_var.get(), self.pick_var(self.block_var))
        return go

    def open_card_list(self):
        self.open_popup((195, 4, 366, 25), CARDS, self.card, self.pick_card)

    def pick_card(self, name):
        self.card = name
        self.render()

    # ---------------------------------------------------------------- mouse
    def build_hot(self):
        self.hot = []
        add = self.hot.append
        eq = self.page == "eq"
        add(((0, 0, PAGES[self.page][0], 30), self.start_window_drag, False))       # title bar = drag the window
        add(((195, 3, 366, 27), lambda e: self.open_card_list(), True))               # device name field
        add(((405, 3, 425, 27), lambda e: self.show("audio"), True))                  # little arrow = audio settings
        add(((369, 3, 404, 27), lambda e: self.toggle(), True))                       # start / stop
        add(((440, 3, 466, 27), lambda e: self.minimize(), True))
        add(((466, 3, 494, 27), lambda e: self.close(), True))
        ny = 281 if eq else 314
        for slot, (_name, page) in enumerate(NAV):
            add(((113 + 32 * slot, ny, 141 + 32 * slot, ny + 28), lambda e, p=page: self.show(p), True))
        if self.page == "fx2":
            add(((190, 34, 305, 56), lambda e: self.show("fx"), True))                  # the "Effects" title goes back
            add(((17, 317, 106, 341), lambda e: self.fx2_default(), True))
            add(((10, SPEED_ROW - 12, 160, SPEED_ROW + 12), lambda e: self.toggle_v2("speed_on"), True))
            add(((165, SPEED_ROW - 12, 445, SPEED_ROW + 12), self.press_v2("speed"), True))
            add(((10, REV_ROW - 12, 160, REV_ROW + 12), lambda e: self.toggle_v2("rev_on"), True))
            add(((165, REV_ROW - 12, 445, REV_ROW + 12), self.press_v2("rev"), True))
            add(((165, VOL_ROW - 12, 445, VOL_ROW + 12), self.press_v2("vol"), True))
            for slot, (key, _label) in enumerate(APPLY_CHOICES):
                add(((110 + 86 * slot, APPLY_ROW, 190 + 86 * slot, APPLY_ROW + 24), lambda e, k=key: self.set_apply(k), True))
            add(((110, SRC_ROW, 380, SRC_ROW + 22), lambda e: self.open_app_list(), True))
            add(((388, SRC_ROW, 470, SRC_ROW + 22), lambda e: self.refresh_app(), True))
        elif self.page == "fx":
            add(((205, 34, 272, 56), lambda e: self.show("fx2"), True))                 # click "Effects" -> voice & app tools
            add(((10, 115, 175, 137), lambda e: self.toggle_reverb(), True))
            add(((17, 317, 106, 341), lambda e: self.effects_default(), True))
            add(((176, 188, 326, 290), self.press_list, True))
            add((self.scroll_box(), self.press_scroll, True))
            add(((356, 164, 464, 186), self.press_amount, True))
        elif eq:
            add(((4, 66, 140, 90), lambda e: self.toggle_eq(), True))
            add((COMBO_BOX, lambda e: self.open_curves(), True))
            add(((17, 284, 106, 308), lambda e: self.eq_default(), True))
            for i in range(7):
                add(((EQ_PANEL[i][0], 98, EQ_PANEL[i][1], 250), lambda e, i=i: self.press_band(e, i), True))
            add(((438, 112, 474, 240), self.press_level, True))
        elif self.page == "audio":
            add(((17, 317, 106, 341), lambda e: None, False))
            for label, y in self.AUDIO_ROWS:
                add(((90, y, 470 if label != "Buffer" else 190, y + 22), self.press_audio_field(label), True))
            add(((90, 244, 190, 268), lambda e: self.toggle(), True))
        else:
            add(((17, 317, 106, 341), lambda e: self.extra_default(), True))
            d = EXTRA[self.page]
            if d["kind"] == "v":
                for i in range(len(d["names"])):
                    add(((44 + i * 67 - 14, 88, 44 + i * 67 + 14, 252), self.press_extra_v(i), True))
            else:
                add(((10, 62, 200, 84), lambda e: self.toggle_extra(), True))
                for i in range(3):
                    add(((165, 140 + i * 50 - 12, 445, 140 + i * 50 + 12), self.press_extra_h(i), True))

    def on_press(self, e):
        if self.popup:
            index = self.popup_index(e)
            pick = self.popup["pick"]
            items = self.popup["items"]
            self.popup = None
            if index >= 0:
                pick(items[index])
            self.render()
            return
        for (x0, y0, x1, y1), callback, _hand in reversed(self.hot):
            if x0 <= e.x < x1 and y0 <= e.y < y1:
                self.drag = callback(e)
                return

    def on_move(self, e):
        if self.drag:
            self.drag(e)

    def on_release(self, _e):
        self.drag = None

    def on_hover(self, e):
        if self.popup:
            index = self.popup_index(e)
            if index != self.popup["hover"]:
                self.popup["hover"] = index
                self.render()
            self.cv.configure(cursor="hand2")
            return
        hand = False
        for (x0, y0, x1, y1), _cb, h in reversed(self.hot):
            if x0 <= e.x < x1 and y0 <= e.y < y1:
                hand = h
                break
        self.cv.configure(cursor="hand2" if hand else "")

    def on_wheel(self, e, direction):
        if self.popup:
            p = self.popup
            p["first"] = max(0, min(len(p["items"]) - p["vis"], p["first"] + direction))
            self.render()
            return
        if self.page != "fx":
            return
        x0, y0, x1, y1 = LIST_BOX
        if x0 <= e.x < x1 and y0 <= e.y < y1:
            self.list_top = max(0, min(len(PRESETS) - LIST_VISIBLE, self.list_top + direction))
            self.render()

    def start_window_drag(self, e):
        ox, oy = e.x_root - self.root.winfo_x(), e.y_root - self.root.winfo_y()
        return lambda ev: self.root.geometry("+%d+%d" % (ev.x_root - ox, ev.y_root - oy))

    # ---------------------------------------------------------------- actions (same calls into the engine as before)
    def toggle_reverb(self):
        self.reverb_on = not self.reverb_on
        self.console.enable(self.reverb_on)
        self.render()

    def toggle_eq(self):
        self.eq_on = not self.eq_on
        self.console.eq_enable(self.eq_on)
        self.render()

    def select_preset(self, index):
        if index != self.preset:
            self.preset = index
            self.console.preset(self.preset)
        self.render()

    def press_list(self, e):
        index = self.list_top + (e.y - LIST_TOP) // LIST_ROW
        if 0 <= index < len(PRESETS) and index < self.list_top + LIST_VISIBLE:
            self.select_preset(index)
        return None

    def press_scroll(self, e):
        def move(ev):
            sx0, sy0, sx1, sy1 = self.scroll_box()
            t0, t1 = self.thumb()
            size = t1 - t0
            frac = (ev.y - sy0 - size / 2.0) / float(max(1, (sy1 - sy0) - size))
            self.list_top = max(0, min(len(PRESETS) - LIST_VISIBLE, int(round(frac * (len(PRESETS) - LIST_VISIBLE)))))
            self.render()
        move(e)
        return move

    def amount_set(self, value):
        value = min(max(float(value), 0.0), 100.0)
        self.amounts[self.preset] = value
        self.console.amount(value)
        self.render()

    def press_amount(self, e):
        def move(ev):
            self.amount_set((ev.x - AMT_X0 - THUMB_W / 2.0) * 100.0 / (AMT_X1 - AMT_X0 - THUMB_W))
        move(e)
        return move

    def press_band(self, e, index):
        def move(ev):
            db = 12.0 - (ev.y - EQ_Y12) * 24.0 / (EQ_Y_12 - EQ_Y12)
            db = float(min(max(round(db), -12), 12))
            if db != self.bands[index]:
                self.bands[index] = db
                self.console.band(index, db)
            self.render()
        move(e)
        return move

    def press_level(self, e):
        def move(ev):
            db = -(ev.y - LV_Y0) * 24.0 / (LV_Y24 - LV_Y0)
            self.level = float(min(max(round(db), -24), 0))
            self.console.level(self.level)
            self.render()
        move(e)
        return move

    def curve_chosen(self, name):                    # equalizer preset picked from the list
        gains = dict(CURVES).get(name)
        if gains is None:
            return
        for index, gain in enumerate(gains):
            self.bands[index] = float(gain)
            self.console.band(index, float(gain))

    def effects_default(self):
        self.amounts = [float(p[1]) for p in PRESETS]
        self.preset = DEFAULT_PRESET
        self.reverb_on = True
        self.push_all()
        self.render()

    def eq_default(self):
        self.bands = [0.0] * 7
        for index in range(7):
            self.console.band(index, 0.0)
        self.level = 0.0
        self.console.level(0.0)
        self.eq_on = False
        self.console.eq_enable(False)
        self.render()

    # ---------------------------------------------------------------- audio
    def toggle(self):
        self.stop() if self.stream is not None else self.start()

    @staticmethod
    def _key(name):
        name = re.sub(r"\(.*?\)", "", name.lower())
        name = re.sub(r"\b(input|output|in|out|[ab]\d)\b", "", name)
        return re.sub(r"\s+", " ", name).strip()

    def looks_like_loop(self, in_name, out_name):
        low = in_name.lower()
        return in_name == out_name or (self._key(in_name) == self._key(out_name) and ("cable" in low or "voicemeeter" in low))

    def start(self):
        if not sd:
            self.messagebox.showerror("EAX Reverb", "The sounddevice module is missing.\nRun:  pip install sounddevice")
            return
        try:
            in_id = next(i for i, n in self.ins if n == self.in_var.get())
            out_id = next(i for i, n in self.outs if n == self.out_var.get())
        except StopIteration:
            self.messagebox.showerror("EAX Reverb", "Choose an input and an output device.")
            self.show("audio")
            return
        if self.looks_like_loop(self.in_var.get(), self.out_var.get()):
            if not self.messagebox.askyesno("EAX Reverb", "Input and Output look like the SAME device / cable.\nThat feeds the sound back into itself (echo, howl, noise).\n\nStart anyway?"):
                return
        in_ch = max(1, min(2, sd.query_devices(in_id)["max_input_channels"]))
        out_ch = max(1, min(2, sd.query_devices(out_id)["max_output_channels"]))
        rate = int(sd.query_devices(out_id)["default_samplerate"]) or 48000
        block = int(self.block_var.get())
        plugin = self.plugin
        pipe = Pipe(rate, block)
        self.pipe = pipe
        buffers = [np.zeros(block, np.float32) for _ in range(4)]

        def in_callback(indata, frames, _time, _status):
            try:
                pipe.push(indata[:, :2] if in_ch > 1 else np.repeat(indata[:, :1], 2, axis=1))
            except Exception:
                pass

        def out_callback(outdata, frames, _time, _status):
            try:
                if frames > len(buffers[0]):
                    for k in range(4):
                        buffers[k] = np.zeros(frames, np.float32)
                left, right, out_left, out_right = (b[:frames] for b in buffers)
                chunk = pipe.pull(frames)
                voice = chunk if chunk is not None else np.zeros((frames, 2), np.float32)
                voice = self.voice_fx(voice)
                app, dry = None, None
                app_pipe = self.app_pipe
                if app_pipe is not None:
                    app = app_pipe.pull(frames)
                    if app is not None:
                        app = app * np.float32(self.v2["vol"] / 50.0)
                mode = self.v2["apply"]
                if app is None and mode != "app":
                    wet = voice                                   # plain case: exactly the old path
                else:
                    wet = np.zeros((frames, 2), np.float32)
                    dry = np.zeros((frames, 2), np.float32)
                    if mode in ("voice", "both"):
                        wet += voice
                    else:
                        dry += voice
                    if app is not None:
                        if mode in ("app", "both"):
                            wet += app
                        else:
                            dry += app
                left[:] = wet[:, 0]
                right[:] = wet[:, 1]
                plugin.process(left, right, out_left, out_right)
                if dry is not None:
                    out_left += dry[:, 0]                         # the part that must stay dry is added after the DLL
                    out_right += dry[:, 1]
                np.nan_to_num(out_left, copy=False)
                np.nan_to_num(out_right, copy=False)
                m1, m0, engine = self.s3d_target, self.s3d_prev, self.s3d
                if engine is not None and (m1 > 0.0 or m0 > 0.0):      # CMSS 3D: after the reverb, before the volume (off = untouched)
                    wet_l, wet_r = engine.process(out_left, out_right)
                    mix = np.linspace(m0, m1, frames, dtype=np.float32) if m1 != m0 else np.float32(m1)
                    out_left += (wet_l - out_left) * mix
                    out_right += (wet_r - out_right) * mix
                    self.s3d_prev = m1
                g1, g0 = self.vol_gain, self.vol_prev          # master volume knob (after the DLL; at full it does nothing)
                if g1 != 1.0 or g0 != 1.0:
                    if g1 != g0:
                        ramp = np.linspace(g0, g1, frames, dtype=np.float32)     # smooth, no clicks between two steps
                        out_left *= ramp
                        out_right *= ramp
                    else:
                        out_left *= np.float32(g1)
                        out_right *= np.float32(g1)
                    self.vol_prev = g1
                    if max(g0, g1) > 1.0:                         # amplifier: soft limiter instead of harsh clipping
                        for ch in (out_left, out_right):
                            mag = np.abs(ch)
                            over = mag > 0.7
                            if over.any():
                                ch[over] = np.sign(ch[over]) * (0.7 + 0.3 * np.tanh((mag[over] - 0.7) / 0.3))
                np.clip(out_left, -1.0, 1.0, out=out_left)       # never send values past full scale (harsh distortion)
                np.clip(out_right, -1.0, 1.0, out=out_right)
                if out_ch == 1:
                    outdata[:, 0] = (out_left + out_right) * 0.5
                else:
                    outdata[:, 0] = out_left
                    outdata[:, 1] = out_right
            except Exception:
                outdata[:] = 0

        extra = None
        if "WASAPI" in self.host_var.get():
            try:
                extra = sd.WasapiSettings(auto_convert=True)
            except Exception:
                extra = None
        safe_latency = max(0.03, 2.0 * block / rate)
        in_stream = out_stream = None
        self.shifter = PitchShifter(rate)
        self.s3d = Spatial3D(rate)
        self.reverser = None
        self.sp_active = self.rev_active = False
        failure = None
        self.cfg = {"rate": rate, "block": block, "latency": safe_latency, "wasapi": extra is not None}
        try:
            plugin.start(rate)
        except Exception as error:
            self.messagebox.showerror("EAX Reverb", "Could not start the reverb engine:\n%s" % error)
            return
        for latency in (("low", safe_latency) if LOW_LATENCY else (safe_latency,)):
            try:
                in_stream = sd.InputStream(samplerate=rate, blocksize=block, device=in_id, channels=in_ch,
                                           dtype="float32", latency=latency, callback=in_callback, extra_settings=extra)
                out_stream = sd.OutputStream(samplerate=rate, blocksize=block, device=out_id, channels=out_ch,
                                             dtype="float32", latency=latency, callback=out_callback, extra_settings=extra)
                in_stream.start()
                out_stream.start()
                failure = None
                break
            except Exception as error:
                failure = error
                for st in (in_stream, out_stream):
                    try:
                        if st is not None:
                            st.close()
                    except Exception:
                        pass
                in_stream = out_stream = None
        if failure is not None or in_stream is None:
            self.stream = None
            self.messagebox.showerror("EAX Reverb", "Could not open the audio devices:\n%s" % failure)
            return
        self.cfg = {"rate": rate, "block": block, "latency": latency, "wasapi": extra is not None}
        self.stream = (in_stream, out_stream)
        self.rate = rate
        self.start_app_source()
        self.start_text.set("Stop")
        self.refresh_status()
        self.render()

    # ---------------------------------------------------------------- voice tools + app source (engine side)
    def voice_fx(self, v):
        """Speed / reverse on the dry voice. Both off (default) = the voice passes through untouched."""
        v2 = self.v2
        if v2["speed_on"] and self.shifter is not None:
            ratio = self.speed_ratio(v2["speed"])
            if abs(ratio - 1.0) > 1e-6:
                if not self.sp_active:
                    self.shifter.reset()
                    self.sp_active = True
                v = self.shifter.process(v, ratio)
        else:
            self.sp_active = False
        if v2["rev_on"]:
            ms = self.rev_ms(v2["rev"])
            if self.reverser is None or self.reverser.ms != ms or not self.rev_active:
                self.reverser = Reverser(self.cfg["rate"], ms)
                self.rev_active = True
            v = self.reverser.process(v)
        else:
            self.rev_active = False
        return v

    def stop_app_source(self):
        self.app_pipe = None
        cap, stream = self.app_cap, self.app_stream
        self.app_cap = self.app_stream = None
        if cap is not None:
            cap.stop()
        if stream is not None:
            try:
                stream.stop()
                stream.close()
            except Exception:
                pass

    def set_app_msg(self, text):                      # may be called from the capture thread: only sets a string
        self.app_msg = text

    def start_app_source(self):
        self.stop_app_source()
        src = self.v2["src"]
        cfg = self.cfg
        if src == "None" or not cfg:
            return
        pipe = Pipe(cfg["rate"], cfg["block"])
        if src.startswith("App: "):
            exe = src[5:]
            pid = find_root_pid(exe)
            if not pid:
                self.app_msg = "%s is not running - start it, it will be picked up automatically" % exe
                return
            cap = AppCapture(pid, cfg["rate"], pipe, self.set_app_msg)
            self.app_msg = "Capturing %s ..." % exe
            self.app_cap, self.app_pipe = cap, pipe
            cap.start()
        elif src.startswith("Device: "):
            name = src[8:]
            if name == self.in_var.get():
                self.app_msg = "That is the same device as your microphone Input - pick another one"
                return
            dev = next((i for i, n in self.ins if n == name), None)
            if dev is None:
                self.app_msg = "Device not found in the current Driver list"
                return
            try:
                ch = max(1, min(2, sd.query_devices(dev)["max_input_channels"]))

                def callback(indata, frames, _time, _status):
                    try:
                        pipe.push(indata[:, :2] if ch > 1 else np.repeat(indata[:, :1], 2, axis=1))
                    except Exception:
                        pass

                extra = sd.WasapiSettings(auto_convert=True) if cfg["wasapi"] else None
                stream = sd.InputStream(samplerate=cfg["rate"], blocksize=cfg["block"], device=dev, channels=ch,
                                        dtype="float32", latency=cfg["latency"], callback=callback, extra_settings=extra)
                stream.start()
            except Exception as error:
                self.app_msg = "Could not open %s: %s" % (name, error)
                return
            self.app_stream, self.app_pipe = stream, pipe
            self.app_msg = "Mixing %s" % name

    def watch_app(self):
        """Every 0.5 s: if the captured app closed, forget it and try again every ~3 s (e.g. you open Chrome later)."""
        cap = self.app_cap
        if cap is not None and not cap.alive():
            self.app_cap = self.app_pipe = None
            cap = None
        if self.v2["src"].startswith("App: ") and cap is None:
            self.retry_tick += 1
            if self.retry_tick >= 6:
                self.retry_tick = 0
                msg = self.app_msg
                self.start_app_source()
                if self.app_cap is None and msg:
                    self.app_msg = msg                   # keep the reason instead of overwriting it every retry
        else:
            self.retry_tick = 0

    def refresh_status(self):
        if self.stream is None:
            return
        pipe = self.pipe
        try:
            driver = sum(float(st.latency) for st in self.stream)                 # input + output driver buffers (seconds)
        except Exception:
            driver = 0.0
        total = 1000 * pipe.count // self.rate + int(driver * 1000)
        self.status.set("Running %d Hz | delay ~%d ms | gaps %d | resync %d" % (
            self.rate, total, pipe.under, pipe.over))
        self.watch_app()
        if self.page in ("audio", "fx2"):
            self.render()
        self.root.after(500, self.refresh_status)

    def stop(self):
        self.stop_app_source()
        if self.stream is not None:
            for st in self.stream:
                try:
                    st.stop()
                    st.close()
                except Exception:
                    pass
            self.plugin.stop()
        self.stream = None
        self.start_text.set("Start")
        self.status.set("Stopped")
        self.render()

    def close(self):
        self.stop()
        try:
            self.write_settings(self.snapshot())
        except Exception:
            pass
        self.root.destroy()
        os._exit(0)          # the DLL owns its memory; leave without touching it again


def boost_priority():
    """Windows: finer timer + a little higher priority, so a small buffer does not crackle while the window is busy."""
    if os.name != "nt":
        return
    try:
        k32 = ctypes.windll.kernel32
        k32.GetCurrentProcess.restype = c.c_void_p
        k32.SetPriorityClass.argtypes = [c.c_void_p, c.c_uint32]
        k32.SetPriorityClass(k32.GetCurrentProcess(), 0x00008000)     # ABOVE_NORMAL_PRIORITY_CLASS
        ctypes.windll.winmm.timeBeginPeriod(1)
    except Exception:
        pass


def main():
    import tkinter as tk
    boost_priority()
    if sd is None:
        print("Missing module: run  pip install numpy sounddevice")
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
