@echo off
where py >nul 2>nul || (echo Python is not installed. Get it from https://www.python.org/downloads/ & pause & exit /b 1)
py -m pip install -q numpy sounddevice
py "%~dp0EAX_Reverb.py"
if errorlevel 1 pause
